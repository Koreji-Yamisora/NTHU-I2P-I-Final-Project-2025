import pygame as pg
import pytmx
from src.utils import Logger

from src.utils import load_tmx, Position, GameSettings, PositionCamera, Teleport, Warp


class Map:
    # Map Properties
    path_name: str
    tmxdata: pytmx.TiledMap
    # Position Argument
    spawn: Position
    teleporters: list[Teleport]
    warps: list[Warp]
    # Rendering Properties
    _surface: pg.Surface
    _collision_map: list[pg.Rect]
    _bush: list[pg.Rect]

    def __init__(
        self,
        path: str,
        tp: list[Teleport],
        spawn: Position,
        warps: list[Warp] | None = None,
    ):
        self.path_name = path
        self.tmxdata = load_tmx(path)
        self.spawn = spawn
        self.teleporters = tp
        self.warps = warps if warps is not None else []

        pixel_w = self.tmxdata.width * GameSettings.TILE_SIZE
        pixel_h = self.tmxdata.height * GameSettings.TILE_SIZE

        # Prebake the map
        self._surface = pg.Surface((pixel_w, pixel_h), pg.SRCALPHA)
        self._render_all_layers(self._surface)
        # Prebake the collision map
        self._collision_map = self._create_collision_map()
        self._bush = self._create_bush()

    def update(self, dt: float):
        return

    def draw(self, screen: pg.Surface, camera: PositionCamera):
        screen.blit(self._surface, camera.transform_position(Position(0, 0)))

        # Draw the hitboxes collision map
        if GameSettings.DRAW_HITBOXES:
            for rect in self._collision_map:
                pg.draw.rect(screen, (255, 0, 0), camera.transform_rect(rect), 1)
            for rect in self._bush:
                pg.draw.rect(screen, (0, 255, 0), camera.transform_rect(rect), 1)

    def check_collision(self, rect: pg.Rect) -> bool:
        """
        [TODO HACKATHON 4]
        Return True if collide if rect param collide with self._collision_map
        Hint: use API colliderect and iterate each rectangle to check
        """
        for collision_rect in self._collision_map:
            if rect.colliderect(collision_rect):
                return True
        return False

    def check_bush(self, rect: pg.Rect) -> bool:
        for bush in self._bush:
            if rect.colliderect(bush):
                return True

        return False

    def check_teleport(self, rect: pg.Rect) -> Teleport | None:
        for teleporter in self.teleporters:
            tp_rect = pg.Rect(
                teleporter.pos.x,
                teleporter.pos.y,
                GameSettings.TILE_SIZE,
                GameSettings.TILE_SIZE,
            )
            if rect.colliderect(tp_rect):
                return teleporter

        return None

    def check_warp(self, rect: pg.Rect) -> Warp | None:
        for warp in self.warps:
            warp_rect = pg.Rect(
                warp.source.x,
                warp.source.y,
                GameSettings.TILE_SIZE,
                GameSettings.TILE_SIZE,
            )

            if rect.colliderect(warp_rect):
                return warp

        return None

    def _render_all_layers(self, target: pg.Surface) -> None:
        for layer in self.tmxdata.visible_layers:
            if isinstance(layer, pytmx.TiledTileLayer):
                self._render_tile_layer(target, layer)
            # elif isinstance(layer, pytmx.TiledImageLayer) and layer.image:
            #     target.blit(layer.image, (layer.x or 0, layer.y or 0))

    def _render_tile_layer(
        self, target: pg.Surface, layer: pytmx.TiledTileLayer
    ) -> None:
        for x, y, gid in layer:
            if gid == 0:
                continue
            image = self.tmxdata.get_tile_image_by_gid(gid)
            if image is None:
                continue

            image = pg.transform.scale(
                image, (GameSettings.TILE_SIZE, GameSettings.TILE_SIZE)
            )
            target.blit(image, (x * GameSettings.TILE_SIZE, y * GameSettings.TILE_SIZE))

    def _create_collision_map(self) -> list[pg.Rect]:
        rects = []
        for layer in self.tmxdata.visible_layers:
            if isinstance(layer, pytmx.TiledTileLayer) and (
                "collision" in layer.name.lower() or "house" in layer.name.lower()
            ):
                for x, y, gid in layer:
                    if gid != 0:
                        """
                        [TODO HACKATHON 4]
                        rects.append(pg.Rect(...))
                        Append the collision rectangle to the rects[] array
                        Remember scale the rectangle with the TILE_SIZE from settings
                        """
                        rects.append(
                            pg.Rect(
                                x * GameSettings.TILE_SIZE,
                                y * GameSettings.TILE_SIZE,
                                GameSettings.TILE_SIZE,
                                GameSettings.TILE_SIZE,
                            )
                        )
        return rects

    def _create_bush(self) -> list[pg.Rect]:
        rects = []
        for layer in self.tmxdata.visible_layers:
            if isinstance(layer, pytmx.TiledTileLayer) and (
                "pokemonbush" in layer.name.lower()
            ):
                for x, y, gid in layer:
                    if gid != 0:
                        rects.append(
                            pg.Rect(
                                x * GameSettings.TILE_SIZE,
                                y * GameSettings.TILE_SIZE,
                                GameSettings.TILE_SIZE,
                                GameSettings.TILE_SIZE,
                            )
                        )
        return rects

    @classmethod
    def from_dict(cls, data: dict) -> "Map":
        tp = [Teleport.from_dict(t) for t in data["teleport"]]
        pos = Position(
            data["player"]["x"] * GameSettings.TILE_SIZE,
            data["player"]["y"] * GameSettings.TILE_SIZE,
        )
        warps = [Warp.from_dict(w) for w in data.get("warps", [])]
        return cls(data["path"], tp, pos, warps)

    def to_dict(self):
        return {
            "path": self.path_name,
            "teleport": [t.to_dict() for t in self.teleporters],
            "warps": [w.to_dict() for w in self.warps],
            "player": {
                "x": self.spawn.x // GameSettings.TILE_SIZE,
                "y": self.spawn.y // GameSettings.TILE_SIZE,
            },
        }
