import pygame as pg

from src.utils import GameSettings
from src.sprites import BackgroundSprite
from src.scenes.scene import Scene
from src.interface.components import Button
from src.core.services import (
    scene_manager,
    sound_manager,
    input_manager,
    resource_manager,
)
from typing import override


class MenuScene(Scene):
    # Background Image
    background: BackgroundSprite
    # Buttons
    play_button: Button
    settings_button: Button

    def __init__(self):
        super().__init__()
        self.background = BackgroundSprite("backgrounds/background1.png")

        px, py = GameSettings.SCREEN_WIDTH // 2, GameSettings.SCREEN_HEIGHT * 3 // 4
        font = resource_manager.get_font("Pokemon solid.ttf", 82)
        self.title = font.render("POKEMON???", True, (255, 64, 32))
        self.title_rect = self.title.get_rect(center=(px, py - 300))

        self.play_button = Button(
            "UI/button_play.png",
            "UI/button_play_hover.png",
            px + 50,
            py,
            100,
            100,
            lambda: scene_manager.change_scene("game"),
        )
        self.settings_button = Button(
            "UI/button_setting.png",
            "UI/button_setting_hover.png",
            px - 150,
            py,
            100,
            100,
            lambda: scene_manager.change_scene("settings"),
        )

    @override
    def enter(self) -> None:
        sound_manager.play_bgm("RBY 101 Opening (Part 1).ogg")
        pass

    @override
    def exit(self) -> None:
        pass

    @override
    def update(self, dt: float) -> None:
        if input_manager.key_pressed(pg.K_SPACE):
            scene_manager.change_scene("game")
            return
        self.play_button.update(dt)
        self.settings_button.update(dt)

    @override
    def draw(self, screen: pg.Surface) -> None:
        self.background.draw(screen)
        screen.blit(self.title, self.title_rect)
        self.play_button.draw(screen)
        self.settings_button.draw(screen)
